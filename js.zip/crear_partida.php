<?php
    include("utils.php");
    arriba("Crear partida");
    
    abajo();

?>